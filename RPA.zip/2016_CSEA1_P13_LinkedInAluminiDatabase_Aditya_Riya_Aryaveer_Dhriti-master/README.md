# 2016_CSEA1_P13_LinkedInAluminiDatabase_Aditya_Riya_Aryaveer_Dhriti
In our project we are using ROBOTIC PROCESS AUTOMATION (RPA) to make alumni database by fetching data from alumni’s LinkedIn profile. The fetched data is stored in database that we have created and later on we are showing the data on google map on the basis of their location in the webapp that we have made.
